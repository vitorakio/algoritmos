#include <stdio.h>
#include <conio.h>
#include <stdlib.h>



main()
{
   int alunos, masc, mmdi, hmmdi, mmenor, hmenor;

   printf ("Informe a quantidade de alunos na sala:");
   scanf ("%d", &quant_alunos);

   quant_alunos = (quant_alunos * 40) / 100;
   hmmdi =

   //quant_alunos = 100%
}
