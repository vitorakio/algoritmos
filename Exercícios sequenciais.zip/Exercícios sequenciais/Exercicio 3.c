#include <stdlib.h>
#include <stdio.h>
#include <conio.h>

main()
{
    int area;

    printf ("Informe a area do circulo:");
        scanf ("%d", &area);

    printf ("A area do circulo e: %d", (3,1415*area^2));

    getch();
}
